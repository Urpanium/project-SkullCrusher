﻿using System;

namespace Level.Generation.PathLayer.Path.SubGenerators
{
    public class RoomGenerator: SubGenerator
    {
        
        /*
         * protected PathGeneratorConfig config;
         * protected Random random;
         */
        
        public RoomGenerator(PathGeneratorConfig config) : base(config)
        {
        }
    }
}