﻿namespace Level.Generation.PathLayer.Snapshots
{
    public enum GenerationStructure
    {
        MustSpawn = 0,
        CanSpawn = 1,
        Corridor = 2
    }
}