﻿namespace Level.Generation.PathLayer.Tiles
{
    public enum TileType
    {
        Common = 0,
        Special
    }
}