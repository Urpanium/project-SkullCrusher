﻿namespace Level.Generation.PathLayer.Path.Decisions
{
    public enum PathDecisionType
    {
        Corridor = 0,
        Room,
        Prototype,
        End
    }
}